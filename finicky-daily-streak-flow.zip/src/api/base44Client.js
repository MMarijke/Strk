import { createClient } from '@base44/sdk';
import { appParams } from '@/lib/app-params';

const { appId, functionsVersion, appBaseUrl } = appParams;

// Do NOT pass token at client creation time - it's read once from
// localStorage and never updates when a different user logs in.
// The SDK reads the token dynamically from localStorage on each
// request instead, which correctly reflects the current session.

export const base44 = createClient({
  appId,
  functionsVersion,
  serverUrl: '',
  requiresAuth: false,
  appBaseUrl
});
