import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { addMinutes, formatISO } from "date-fns";
import { useQuery } from "@tanstack/react-query";

const DURATIONS = [25, 45, 60];

function genCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

export default function StartFocusModal({ open, onOpenChange, userEmail, userName, onSessionCreated }) {
  const [duration, setDuration] = useState(25);
  const [groupId, setGroupId] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: groups = [] } = useQuery({
    queryKey: ["groups", userEmail],
    queryFn: () => userEmail
      ? base44.entities.Group.filter({ '$or': [{ created_by: userEmail }, { member_emails: { '$in': [userEmail] } }] }, "-created_date")
      : [],
    enabled: !!userEmail,
  });

  const handleStart = async () => {
    setLoading(true);
    const now = new Date();
    const session = await base44.entities.FocusSession.create({
      host_email: userEmail,
      host_name: userName,
      group_id: groupId || undefined,
      duration_minutes: duration,
      started_at: formatISO(now),
      ends_at: formatISO(addMinutes(now, duration)),
      status: "active",
      participant_emails: [userEmail],
      session_code: genCode(),
    });
    setLoading(false);
    onOpenChange(false);
    onSessionCreated(session);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Start Focus Session</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-1">
          {/* Duration */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Duration</p>
            <div className="flex gap-2">
              {DURATIONS.map((d) => (
                <button
                  key={d}
                  onClick={() => setDuration(d)}
                  className={cn(
                    "flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all border",
                    duration === d
                      ? "bg-primary text-primary-foreground border-primary shadow"
                      : "bg-muted text-muted-foreground border-transparent hover:border-border"
                  )}
                >
                  {d} min
                </button>
              ))}
            </div>
          </div>

          {/* Group (optional) */}
          {groups.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Group (optional)</p>
              <select
                value={groupId}
                onChange={(e) => setGroupId(e.target.value)}
                className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring"
              >
                <option value="">No group</option>
                {groups.map((g) => (
                  <option key={g.id} value={g.id}>{g.name}</option>
                ))}
              </select>
            </div>
          )}

          <Button className="w-full rounded-xl h-11 font-semibold" onClick={handleStart} disabled={loading}>
            {loading ? "Starting…" : "Start Session 🎯"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}