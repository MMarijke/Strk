import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import BottomTabBar from "./BottomTabBar";

// Pages that show the bottom tab bar
const TAB_PAGES = ["/Dashboard", "/Trends", "/Social", "/Settings", "/Badges"];

export default function AppLayout() {
  const { pathname } = useLocation();
  const { user } = useAuth();

  const showTabs = TAB_PAGES.some((p) => pathname === p || pathname.startsWith(p + "/"));

  const { data: reactions = [] } = useQuery({
    queryKey: ["reactions", user?.email],
    queryFn: () => user?.email
      ? base44.entities.Reaction.filter({ recipient_email: user.email }, "-created_date")
      : [],
    enabled: !!user?.email,
  });
  const unreadReactions = reactions.filter((r) => !r.read).length;

  return (
    <div className="flex flex-col min-h-screen">
      <main className={showTabs ? "pb-[calc(3.75rem+env(safe-area-inset-bottom))]" : ""}>
        <Outlet />
      </main>
      {showTabs && <BottomTabBar unreadReactions={unreadReactions} />}
    </div>
  );
}